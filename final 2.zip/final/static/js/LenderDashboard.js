// static/js/LenderDashboard.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const LenderDashboard = () => {
  const [dashboard, setDashboard] = useState(null);

  useEffect(() => {
    axios.get('/api/dashboard/lender/')
      .then(res => setDashboard(res.data))
      .catch(err => console.error('Error fetching lender dashboard:', err));
  }, []);

  if (!dashboard) return <div className="text-center mt-10">Loading...</div>;

  const { total_lent, total_returns, borrowers } = dashboard;

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-4xl font-bold text-center text-green-600 mb-10">
        UPI Loan Nexus <span className="text-black">Lender Dashboard</span>
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Investment Summary */}
        <div className="bg-white rounded-xl shadow p-5 text-center">
          <h2 className="text-lg font-semibold text-green-800 mb-4">📊 Investment Summary</h2>
          <p className="text-3xl font-bold text-green-600">{total_lent}</p>
          <p className="text-sm text-gray-500 mb-3">Total Lent</p>
          <hr className="mb-3" />
          <p className="text-blue-600 font-medium">{total_returns}</p>
          <p className="text-sm text-gray-400">Total Interest Earned</p>
        </div>

        {/* Borrowers List */}
        <div className="bg-white rounded-xl shadow p-5">
          <h2 className="text-lg font-semibold text-green-800 mb-4">🤝 Your Borrowers</h2>
          {borrowers.length === 0 ? (
            <p className="text-gray-400">No borrowers yet</p>
          ) : borrowers.map((borrower, index) => (
            <div key={index} className="border rounded-lg p-3 mb-3">
              <div className="flex justify-between">
                <div>
                  <p className="font-semibold text-lg">{borrower.name}</p>
                  <p className="text-gray-500 text-sm">Amount: {borrower.amount}</p>
                </div>
                <div className={`text-sm font-medium ${borrower.status === 'Late' ? 'text-red-600' : 'text-green-600'}`}>
                  ⏱ {borrower.status} ({borrower.due})
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <footer className="mt-12 text-center text-gray-400 text-sm">
        UPI Loan Nexus ©️ 2025 – Empowering Micro Lending
      </footer>
    </div>
  );
};

export default LenderDashboard;
