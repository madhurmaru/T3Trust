from twilio.rest import Client

account_sid = "AC07e43d43a76be13f43fe9641b72a2b77"
auth_token = "9440e19b8f4cc1e4c2686bd97c34c3e9"

client = Client(account_sid, auth_token)

message = client.messages.create(
    from_="+18653535869",
    to="+919155223591",
    body="This is a test message from Twilio!"  # <-- Add a message body
)

print(f"Message SID: {message.sid}")
