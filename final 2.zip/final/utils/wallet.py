# wallet_utils/wallet.py
import uuid

wallet_store = {}

def create_wallet(user_identifier):
    wallet_address = str(uuid.uuid4())
    wallet_store[wallet_address] = {
        'balance': 0.0,
        'owner': user_identifier
    }
    return wallet_address

def get_wallet_balance(wallet_address):
    return wallet_store.get(wallet_address, {}).get('balance', 0.0)

def add_to_wallet(wallet_address, amount):
    if wallet_address in wallet_store:
        wallet_store[wallet_address]['balance'] += amount

def deduct_from_wallet(wallet_address, amount):
    if wallet_store.get(wallet_address, {}).get('balance', 0) >= amount:
        wallet_store[wallet_address]['balance'] -= amount
        return True
    return False
