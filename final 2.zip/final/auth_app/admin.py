
from django.contrib import admin
from .models import UserProfile, Loan

class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'phone_number', 'role', 'age', 'dob')
    search_fields = ('phone_number', 'full_name')
    list_filter = ('role',)

admin.site.register(UserProfile, UserProfileAdmin)
admin.site.register(Loan)