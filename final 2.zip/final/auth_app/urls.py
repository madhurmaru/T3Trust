from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signup_page, name='signup_page'),
    path('login/', views.login_page, name='login_page'),
    
    path('auth/send-otp/', views.send_otp, name='send_otp'),
    path('auth/verify-otp/', views.verify_otp, name='verify_otp'),
    path('auth/signup-user/', views.signup_user, name='signup_user'),
    path('auth/login-user/', views.login_user, name='login_user'),
    path('api/dashboard/borrower/', views.borrower_dashboard, name='borrower_dashboard'),
    path('api/dashboard/lender/', views.lender_dashboard, name='lender_dashboard'),
]
