from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.hashers import make_password, check_password
from .models import UserProfile
from twilio.rest import Client
import os
import random
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from utils.wallet import create_wallet  # from the zip file we'll integrate
import random
import json

def register_user(data):
    user = User.objects.create_user(
        username=data['phone_number'],
        password=data['password']
    )
    role = data['role']

    profile = UserProfile.objects.create(
        user=user,
        full_name=data['full_name'],
        phone_number=data['phone_number'],
        role=role,
    )

    # Assign wallet
    wallet_address = create_wallet(data['phone_number'])
    profile.wallet_address = wallet_address

    # Borrower logic
    if role == 'borrower':
        import random
        multiplier = random.randint(1, 3)
        profile.purchase_power = multiplier * 20000

    # Lender logic
    elif role == 'lender':
        profile.max_lend_amount = int(data['max_lend_amount'])
        profile.expected_interest = float(data['expected_interest'])

    profile.save()
    return profile


OTP_STORE = {}  # In-memory store for OTPs

# Render signup page
def signup_page(request):
    return render(request, "auth_app/signup.html")

# Render login page
def login_page(request):
    return render(request, "auth_app/login.html")

# Send OTP via Twilio
@csrf_exempt
def send_otp(request):
    if request.method == "POST":
        phone_number = request.POST.get("phone_number")
        otp = str(random.randint(1000, 9999))
        OTP_STORE[phone_number] = otp

        account_sid = os.getenv('TWILIO_ACCOUNT_SID')
        auth_token = os.getenv('TWILIO_AUTH_TOKEN')
        twilio_number = os.getenv('TWILIO_PHONE_NUMBER')

        try:
            client = Client(account_sid, auth_token)
            client.messages.create(
                body=f"Your OTP is {otp}",
                from_=twilio_number,
                to=phone_number
            )
            return JsonResponse({"message": "OTP sent successfully."})
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)

    return JsonResponse({"error": "Invalid request."}, status=400)

# Verify OTP
@csrf_exempt
def verify_otp(request):
    if request.method == "POST":
        phone_number = request.POST.get("phone_number")
        otp = request.POST.get("otp")

        if OTP_STORE.get(phone_number) == otp:
            return JsonResponse({"message": "OTP verified successfully."})
        else:
            return JsonResponse({"error": "Invalid OTP."}, status=400)

@csrf_exempt
def signup_user(request):
    if request.method == "POST":
        phone_number = request.POST.get("phone_number")
        password = request.POST.get("password")
        full_name = request.POST.get("full_name")
        role = request.POST.get("role")
        age = request.POST.get("age")
        dob = request.POST.get("dob")
        
        # Lender specific
        max_lend_amount = request.POST.get("max_lend_amount")
        expected_interest = request.POST.get("expected_interest")

        if User.objects.filter(username=phone_number).exists():
            return JsonResponse({"error": "Phone number already registered."}, status=400)

        user = User.objects.create_user(username=phone_number, password=password)
        
        user_profile = UserProfile.objects.create(
            user=user,
            phone_number=phone_number,
            full_name=full_name,
            role=role,
            age=age,
            dob=dob
        )

        if role == "borrower":
            user_profile.purchase_power = random.randint(1, 5) * 20000  # e.g., ₹20k, ₹40k, ..., ₹100k
        elif role == "lender":
            user_profile.max_lend_amount = max_lend_amount
            user_profile.expected_interest = expected_interest

        user_profile.save()

        return JsonResponse({"message": "User registered successfully."})
    
    return JsonResponse({"error": "Invalid request."}, status=400)


# Handle login
@csrf_exempt
def login_user(request):
    if request.method == "POST":
        phone_number = request.POST.get("phone_number")
        password = request.POST.get("password")

        if not phone_number or not password:
            return JsonResponse({"error": "Both phone number and password are required."}, status=400)

        # Authenticate using phone number as username
        user = authenticate(username=phone_number, password=password)

        if user is not None:
            login(request, user)
            return JsonResponse({"message": "Login successful."})
        else:
            return JsonResponse({"error": "Invalid credentials."}, status=401)

    return JsonResponse({"error": "Invalid request method."}, status=400)


# views.py
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Borrower, Lender, Loan, Wallet

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def borrower_dashboard(request):
    borrower = Borrower.objects.get(user=request.user)
    wallet = Wallet.objects.get(user=request.user)
    loans = Loan.objects.filter(borrower=borrower, status='active')

    lenders = Lender.objects.exclude(user=request.user)  # available lenders

    data = {
        "active_loans": [
            {
                "amount": f"₹{loan.amount}",
                "interest": f"{loan.interest_rate}%",
                "due": f"Due in {loan.days_left()} days"
            } for loan in loans
        ],
        "credit_score": borrower.credit_score,
        "wallet_balance": f"₹{wallet.balance}",
        "interest_payable": f"₹{wallet.interest_due}",
        "available_lenders": [
            {
                "name": lender.user.first_name,
                "amount": f"₹{lender.max_lend_amount}",
                "interest": f"{lender.expected_interest}%"
            } for lender in lenders
        ]
    }
    return Response(data)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def lender_dashboard(request):
    lender = Lender.objects.get(user=request.user)
    loans = Loan.objects.filter(lender=lender)
    borrowers = [
        {
            "name": loan.borrower.user.first_name,
            "amount": f"₹{loan.amount}",
            "status": "On Time" if loan.is_on_time() else "Late",
            "due": f"{loan.days_left()} days"
        } for loan in loans if loan.status == 'active'
    ]
    total_lent = sum([loan.amount for loan in loans])
    total_interest = sum([loan.interest_accrued for loan in loans])

    data = {
        "total_lent": f"₹{total_lent}",
        "total_returns": f"₹{total_interest}",
        "borrowers": borrowers
    }
    return Response(data)
