# models.py
from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    ROLE_CHOICES = (('borrower', 'Borrower'), ('lender', 'Lender'))

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    full_name = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=15, unique=True)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)

    # Borrower-specific
    purchase_power = models.IntegerField(default=0)

    # Lender-specific
    max_lend_amount = models.IntegerField(null=True, blank=True)
    expected_interest = models.FloatField(null=True, blank=True)

    # Wallet
    wallet_address = models.CharField(max_length=255, unique=True, blank=True, null=True)

    def __str__(self):
        return f"{self.full_name} ({self.role})"

class Loan(models.Model):
    borrower = models.ForeignKey(UserProfile, related_name='borrowed_loans', on_delete=models.CASCADE)
    lender = models.ForeignKey(UserProfile, related_name='lent_loans', on_delete=models.CASCADE)
    amount = models.IntegerField()
    interest_rate = models.FloatField()
    due_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.borrower.full_name} → {self.lender.full_name} : ₹{self.amount}"
