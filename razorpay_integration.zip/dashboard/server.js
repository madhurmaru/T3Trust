require('dotenv').config();
const express = require('express');
const Razorpay = require('razorpay');
const crypto = require('crypto');
const cors = require('cors');
const fs = require('fs').promises;
const path = require('path');

const app = express();

// Add CORS middleware
app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// Initialize Razorpay
const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET
});

// Create order endpoint
// Update the create-order endpoint
app.post('/create-order', async (req, res) => {
    try {
        const { amount } = req.body;
        const order = await razorpay.orders.create({
            amount: amount, // Use the amount sent from frontend
            currency: 'INR',
            receipt: 'receipt_' + Date.now()
        });
        res.json(order);
    } catch (error) {
        res.status(500).send(error);
    }
});

// Verify payment endpoint
const WALLETS_FILE = path.join(__dirname, 'wallets.json');

// Initialize wallets if doesn't exist
async function initializeWallets() {
    try {
        await fs.access(WALLETS_FILE);
    } catch {
        await fs.writeFile(WALLETS_FILE, JSON.stringify({
            lender: { balance: 0 },
            borrower: { balance: 0 }
        }));
    }
}

initializeWallets();

// Update wallet balance endpoint
app.post('/verify-payment', async (req, res) => {
    const {
        razorpay_payment_id,
        razorpay_order_id,
        razorpay_signature,
        amount,
        walletType // 'lender' or 'borrower'
    } = req.body;

    const body = razorpay_order_id + '|' + razorpay_payment_id;
    const expectedSignature = crypto
        .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
        .update(body.toString())
        .digest('hex');

    const isAuthentic = expectedSignature === razorpay_signature;

    if (isAuthentic) {
        try {
            const walletsData = JSON.parse(await fs.readFile(WALLETS_FILE, 'utf8'));
            walletsData[walletType].balance += parseFloat(amount);
            await fs.writeFile(WALLETS_FILE, JSON.stringify(walletsData));
            
            res.json({ 
                success: true, 
                balance: walletsData[walletType].balance 
            });
        } catch (error) {
            console.error('Wallet update error:', error);
            res.status(500).json({ success: false, error: 'Wallet update failed' });
        }
    } else {
        res.status(400).json({ success: false, error: 'Invalid signature' });
    }
});

// Get wallet balances
app.get('/wallet-balances', async (req, res) => {
    try {
        const walletsData = JSON.parse(await fs.readFile(WALLETS_FILE, 'utf8'));
        res.json(walletsData);
    } catch (error) {
        res.status(500).json({ error: 'Failed to get wallet balances' });
    }
});

// Transfer money between wallets
app.post('/transfer', async (req, res) => {
    try {
        const { amount } = req.body;
        const walletsData = JSON.parse(await fs.readFile(WALLETS_FILE, 'utf8'));
        
        if (walletsData.lender.balance < amount) {
            return res.status(400).json({ error: 'Insufficient funds in lender wallet' });
        }

        walletsData.lender.balance -= parseFloat(amount);
        walletsData.borrower.balance += parseFloat(amount);
        
        await fs.writeFile(WALLETS_FILE, JSON.stringify(walletsData));
        
        res.json({
            success: true,
            lenderBalance: walletsData.lender.balance,
            borrowerBalance: walletsData.borrower.balance
        });
    } catch (error) {
        res.status(500).json({ error: 'Transfer failed' });
    }
});

app.listen(3000, () => {
    console.log('Server running on port 3000');
});