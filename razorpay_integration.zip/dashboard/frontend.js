// Remove these lines and their related code
// const payButton = document.getElementById('payButton');
// const amountInput = document.getElementById('amountInput');
// payButton.addEventListener('click', async () => { ... });
// async function updateWalletDisplay() { ... }

// Keep only these lines and below
const lenderAddButton = document.getElementById('lenderAddButton');
const borrowerAddButton = document.getElementById('borrowerAddButton');
const lenderAmountInput = document.getElementById('lenderAmountInput');
const borrowerAmountInput = document.getElementById('borrowerAmountInput');
const lendButton = document.getElementById('lendButton');
const lendAmountInput = document.getElementById('lendAmountInput');

// Function to handle Razorpay payment
async function handlePayment(amount, walletType) {
    try {
        const amount_paise = Math.floor(parseFloat(amount) * 100);
        
        if (amount_paise < 100) {
            alert('Please enter an amount greater than ₹1');
            return;
        }

        const response = await fetch('http://localhost:3000/create-order', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ amount: amount_paise })
        });
        
        if (!response.ok) {
            throw new Error('Failed to create order');
        }
        
        const order = await response.json();

        const options = {
            key: 'rzp_test_VaL03l9g0cEn13',
            amount: order.amount,
            currency: "INR",
            name: "P2P Lending Wallet",
            description: `${walletType} Wallet Recharge`,
            order_id: order.id,
            handler: async function (response) {
                try {
                    const verifyResponse = await fetch('http://localhost:3000/verify-payment', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            razorpay_payment_id: response.razorpay_payment_id,
                            razorpay_order_id: response.razorpay_order_id,
                            razorpay_signature: response.razorpay_signature,
                            amount: order.amount/100,
                            walletType: walletType
                        })
                    });
                    
                    if (!verifyResponse.ok) {
                        throw new Error('Payment verification failed');
                    }

                    const verification = await verifyResponse.json();
                    if (verification.success) {
                        if (walletType === 'lender') {
                            lenderAmountInput.value = '';
                        } else {
                            borrowerAmountInput.value = '';
                        }
                        updateWalletBalances();
                        alert(`Successfully added ₹${order.amount/100} to ${walletType}'s wallet!`);
                    } else {
                        alert('Payment verification failed!');
                    }
                } catch (error) {
                    console.error('Verification error:', error);
                    alert('Payment verification failed: ' + error.message);
                }
            },
            prefill: {
                name: "Test User",
                email: "test@example.com",
                contact: "9999999999"
            },
            theme: {
                color: "#3498db"
            }
        };

        const rzp1 = new Razorpay(options);
        rzp1.on('payment.failed', function (response) {
            alert('Payment failed: ' + response.error.description);
        });
        rzp1.open();
    } catch (error) {
        console.error('Error:', error);
        alert('Error: ' + error.message);
    }
}

// Add money to lender wallet
lenderAddButton.addEventListener('click', () => {
    const amount = lenderAmountInput.value;
    if (!amount || amount <= 0) {
        alert('Please enter a valid amount');
        return;
    }
    handlePayment(amount, 'lender');
});

// Add money to borrower wallet
borrowerAddButton.addEventListener('click', () => {
    const amount = borrowerAmountInput.value;
    if (!amount || amount <= 0) {
        alert('Please enter a valid amount');
        return;
    }
    handlePayment(amount, 'borrower');
});

// Update wallet balances
async function updateWalletBalances() {
    try {
        const response = await fetch('http://localhost:3000/wallet-balances');
        const data = await response.json();
        
        document.getElementById('lenderBalance').textContent = `₹${data.lender.balance.toFixed(2)}`;
        document.getElementById('borrowerBalance').textContent = `₹${data.borrower.balance.toFixed(2)}`;
    } catch (error) {
        console.error('Failed to update wallet balances:', error);
    }
}

// Handle lending
lendButton.addEventListener('click', async () => {
    const amount = parseFloat(lendAmountInput.value || '0');
    if (amount < 1) {
        alert('Please enter an amount to lend');
        return;
    }

    try {
        const response = await fetch('http://localhost:3000/transfer', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ amount })
        });

        const result = await response.json();
        if (response.ok) {
            alert(`Successfully lent ₹${amount}`);
            lendAmountInput.value = '';
            updateWalletBalances();
        } else {
            alert(result.error || 'Transfer failed');
        }
    } catch (error) {
        console.error('Transfer error:', error);
        alert('Transfer failed: ' + error.message);
    }
});

// Initialize wallet balances
document.addEventListener('DOMContentLoaded', updateWalletBalances);