urlpatterns = [
    path('api/create-order/', views.create_order),
    path('api/wallet/add-money/', views.add_money),
    path('api/wallet/', views.get_wallet),
]
