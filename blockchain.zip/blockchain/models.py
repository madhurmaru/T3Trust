class Wallet(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    balance = models.FloatField(default=0.0)

class Transaction(models.Model):
    wallet = models.ForeignKey(Wallet, on_delete=models.CASCADE)
    amount = models.FloatField()
    tx_type = models.CharField(max_length=10)  # credit, debit, repay
    prev_hash = models.TextField(null=True, blank=True)
    tx_hash = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        data = f"{self.wallet.id}{self.amount}{self.tx_type}{self.timestamp}{self.prev_hash or '0'}"
        self.tx_hash = hashlib.sha256(data.encode()).hexdigest()
        super().save(*args, **kwargs)
