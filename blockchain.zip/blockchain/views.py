import razorpay
client = razorpay.Client(auth=("RAZORPAY_KEY", "RAZORPAY_SECRET"))

@csrf_exempt
def create_order(request):
    data = json.loads(request.body)
    amount = int(data['amount']) * 100  # in paise
    order = client.order.create(dict(amount=amount, currency="INR", payment_capture='1'))
    return JsonResponse(order)

@csrf_exempt
def add_money(request):
    user = request.user
    data = json.loads(request.body)
    amount = float(data['amount'])

    wallet = Wallet.objects.get(user=user)
    last_tx = Transaction.objects.filter(wallet=wallet).order_by('-timestamp').first()
    prev_hash = last_tx.tx_hash if last_tx else "0"

    tx = Transaction.objects.create(wallet=wallet, amount=amount, tx_type='credit', prev_hash=prev_hash)
    wallet.balance += amount
    wallet.save()
    return JsonResponse({'balance': wallet.balance, 'tx_hash': tx.tx_hash})

def get_wallet(request):
    wallet = Wallet.objects.get(user=request.user)
    txs = Transaction.objects.filter(wallet=wallet).order_by('-timestamp')
    tx_list = [{
        'amount': tx.amount,
        'type': tx.tx_type,
        'timestamp': tx.timestamp,
        'hash': tx.tx_hash
    } for tx in txs]
    return JsonResponse({'balance': wallet.balance, 'transactions': tx_list})
