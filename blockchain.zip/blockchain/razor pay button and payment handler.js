async function startRazorpay(amount) {
    const res = await fetch('/api/create-order/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount })
    });
    const order = await res.json();
  
    const options = {
      key: "YOUR_PUBLIC_KEY",
      amount: order.amount,
      currency: "INR",
      name: "T3TRUST Wallet",
      order_id: order.id,
      handler: async function (response) {
        await fetch('/api/wallet/add-money/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCSRFToken()
          },
          body: JSON.stringify({ amount: order.amount / 100 })
        });
        alert('✅ Wallet credited!');
        showWallet(); // refresh data
      }
    };
  
    const rzp = new Razorpay(options);
    rzp.open();
  }
  