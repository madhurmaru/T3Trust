async function showWallet() {
    const res = await fetch('/api/wallet/');
    const data = await res.json();
  
    document.getElementById("wallet-balance").innerText = `₹${data.balance}`;
    const txList = document.getElementById("transaction-history");
    txList.innerHTML = "";
  
    data.transactions.forEach(tx => {
      txList.innerHTML += `
        <div class="tx-card">
          <strong>${tx.type.toUpperCase()}</strong> - ₹${tx.amount}<br/>
          ${new Date(tx.timestamp).toLocaleString()}<br/>
          <code>${tx.hash.slice(0, 20)}...</code>
        </div>`;
    });
  }
  