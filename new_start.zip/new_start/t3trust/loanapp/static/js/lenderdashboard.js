document.addEventListener('DOMContentLoaded', function() {
    // Mock data
    const totalLent = '₹28,000';
    const totalReturns = '₹2,500';
    const borrowers = [
        { name: 'Ankit', amount: '₹5,000', status: 'On Time', due: '5 days' },
        { name: 'Neha', amount: '₹3,000', status: 'Late', due: '2 days' },
        { name: 'Rohan', amount: '₹10,000', status: 'On Time', due: '12 days' }
    ];

    // Populate Investment Summary
    const investmentSummary = document.getElementById('investment-summary');
    investmentSummary.innerHTML = `
        <p class="text-3xl font-bold text-green-600">${totalLent}</p>
        <p class="text-sm text-gray-500 mb-3">Total Lent</p>
        <hr class="mb-3" />
        <p class="text-blue-600 font-medium">${totalReturns}</p>
        <p class="text-sm text-gray-400">Total Interest Earned</p>
    `;

    // Populate Borrowers List
    const borrowerList = document.getElementById('borrower-list');
    borrowers.forEach(borrower => {
        const div = document.createElement('div');
        div.className = 'border rounded-lg p-3 mb-3';
        div.innerHTML = `
            <div class="flex justify-between">
                <div>
                    <p class="font-semibold text-lg">${borrower.name}</p>
                    <p class="text-gray-500 text-sm">Amount: ${borrower.amount}</p>
                </div>
                <div class="text-sm font-medium ${borrower.status === 'Late' ? 'text-red-600' : 'text-green-600'}">
                    ⏱ ${borrower.status} (${borrower.due})
                </div>
            </div>
        `;
        borrowerList.appendChild(div);
    });
});