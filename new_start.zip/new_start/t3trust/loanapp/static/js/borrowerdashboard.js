document.addEventListener('DOMContentLoaded', function() {
    // Mock data
    const activeLoans = [
        { id: 1, amount: '₹5,000', interest: '8%', due: 'Due in 10 days' },
        { id: 2, amount: '₹2,000', interest: '10%', due: 'Due in 5 days' }
    ];
    const creditScore = 760;
    const walletBalance = '₹2,500';
    const interestPayable = '₹150';
    const lenders = [
        { name: 'Ravi', amount: '₹10,000', interest: '10%' },
        { name: 'Priya', amount: '₹5,000', interest: '8%' },
        { name: 'Akash', amount: '₹8,000', interest: '9%' },
        { name: 'Sunita', amount: '₹15,000', interest: '11%' }
    ];

    // Populate Active Loans
    const activeLoansDiv = document.getElementById('active-loans');
    activeLoans.forEach(loan => {
        const div = document.createElement('div');
        div.className = 'flex justify-between items-center border p-3 rounded-lg mb-3';
        div.innerHTML = `
            <div>
                <p class="font-medium">${loan.amount}</p>
                <p class="text-sm text-gray-500">at ${loan.interest} interest</p>
            </div>
            <div class="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm">
                📅 ${loan.due}
            </div>
        `;
        activeLoansDiv.appendChild(div);
    });

    // Populate Credit Score
    const creditScoreDiv = document.getElementById('credit-score');
    const scoreStatus = creditScore >= 750 ? { color: 'text-green-600 border-green-600/50', label: 'Good' } :
                       creditScore >= 600 ? { color: 'text-yellow-600 border-yellow-600/50', label: 'Fair' } :
                       { color: 'text-red-600 border-red-600/50', label: 'Poor' };
    creditScoreDiv.innerHTML = `
        <div class="w-32 h-32 rounded-full border-8 ${creditScore >= 750 ? 'border-green-400' : creditScore >= 600 ? 'border-yellow-400' : 'border-red-400'} flex items-center justify-center text-3xl font-bold">
            ${creditScore}
        </div>
        <p class="text-gray-500 mt-2">out of 1000</p>
        <p class="mt-2 px-3 py-1 rounded-full text-sm ${scoreStatus.color} border">${scoreStatus.label}</p>
    `;

    // Populate Wallet Balance
    const walletBalanceDiv = document.getElementById('wallet-balance');
    walletBalanceDiv.innerHTML = `
        <p class="text-3xl font-bold">${walletBalance}</p>
        <p class="text-sm text-gray-500 mb-3">Current Balance</p>
        <hr class="mb-3" />
        <p class="text-red-600 font-medium">${interestPayable}</p>
        <p class="text-sm text-gray-400">Upcoming Interest Payable</p>
        <p class="text-xs text-gray-400 mt-1 italic">All transactions processed via this wallet.</p>
    `;

    // Populate Available Lenders
    const lenderList = document.getElementById('lender-list');
    lenders.forEach(lender => {
        const div = document.createElement('div');
        div.className = 'border rounded-lg p-3';
        div.innerHTML = `
            <div class="flex justify-between items-center mb-1">
                <p class="font-semibold">${lender.name}</p>
                <span class="bg-blue-100 text-blue-700 text-xs px-2 py-0.5 rounded-full">${lender.interest} interest</span>
            </div>
            <p class="text-lg font-bold mb-2">${lender.amount}</p>
            <button class="w-full bg-blue-600 text-white py-1 rounded hover:bg-blue-700 transition">Request</button>
        `;
        lenderList.appendChild(div);
    });

    // Add basic interactivity (mock request submission)
    lenderList.querySelectorAll('button').forEach(button => {
        button.addEventListener('click', () => {
            console.log('Loan Request Submitted');
        });
    });
});